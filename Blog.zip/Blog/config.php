<?php 

$server = "sql105.epizy.com";
$username = "epiz_31840082";
$password = "ZNMzUyQ7GYUpSZ";
$database = "epiz_31840082_db_blog";

$conn = mysqli_connect($server, $username, $password, $database);

if (!$conn) {
    die("<script>alert('Connection Failed.')</script>");
}